package com.example.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class QuerryActivity extends AppCompatActivity {

   EditText name,phone,address,query1;

    Button add;

    DatabaseReference databaseReference;
    StaffDataGet staffDataGet;

    long maxId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.querry_activity);

        name  = findViewById(R.id.n1);
        phone = findViewById(R.id.n2);
        address = findViewById(R.id.n3);
        query1 = findViewById(R.id.n4);

        add = findViewById(R.id.addbtn);



        staffDataGet = new StaffDataGet();

        databaseReference = FirebaseDatabase.getInstance().getReference().child("staff_list");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                maxId = dataSnapshot.getChildrenCount();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nameTx = name.getText().toString();
                String phoneTx = phone.getText().toString();
                String addressTx = address.getText().toString();
                String query =  query1.getText().toString();


                HashMap<String , String> hashMap = new HashMap<>();

                hashMap.put("name", nameTx);
                hashMap.put("phone", phoneTx);
                hashMap.put("address", addressTx);
                hashMap.put("query",query);

                databaseReference.child("id"+maxId).setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                         if (task.isSuccessful()){
                             Toast.makeText(QuerryActivity.this, "upload successfull", Toast.LENGTH_SHORT).show();
                         }else Toast.makeText(QuerryActivity.this, "failed", Toast.LENGTH_SHORT).show();
                    }
                });

                Toast.makeText(QuerryActivity.this, ""+nameTx+phoneTx+addressTx+query, Toast.LENGTH_SHORT).show();
                finish();

            }
        });
    }
}
