package com.example.project.ui.gallery;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class GalleryViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public GalleryViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("এই এ্যাপটি কৃষকদের জমি চাষে বিভিন্ন প্রকারের সাহায্যে ব্যবহৃত হয় এবং ফসলের ছবি দেখে রোগ সনাক্তকরণে কার্যকরী ভূমিকা রাখে।");
    }

    public LiveData<String> getText() {
        return mText;
    }
}