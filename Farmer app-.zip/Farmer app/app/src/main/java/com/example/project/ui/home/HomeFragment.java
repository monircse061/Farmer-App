package com.example.project.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.project.Crops_Activity;
import com.example.project.MoslaActivity;
import com.example.project.R;
import com.example.project.QuerryActivity;

public class HomeFragment extends Fragment implements View.OnClickListener{
   private ImageButton crops, fruit, vegetable, flower, others,mosla;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_home, container, false);

        crops = root.findViewById(R.id.cropsId);
        fruit = root.findViewById(R.id.fruitId);
        vegetable = root.findViewById(R.id.vegetableId);
        flower = root.findViewById(R.id.flowerId);
        others = root.findViewById(R.id.othersId);
        mosla = root.findViewById(R.id.moslaId);



        crops.setOnClickListener(this);
        vegetable.setOnClickListener(this);
        fruit.setOnClickListener(this);
        flower.setOnClickListener(this);
        others.setOnClickListener(this);
        mosla.setOnClickListener(this);




        return root;
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.moslaId){

            startActivity(new Intent(getContext(), MoslaActivity.class));

        }

        if(v.getId()==R.id.othersId){
            Toast.makeText(getContext(), "other", Toast.LENGTH_SHORT).show();
        }


        if(v.getId()==R.id.vegetableId){
            Toast.makeText(getContext(), "other", Toast.LENGTH_SHORT).show();
        }
        if(v.getId()==R.id.flowerId){
            Toast.makeText(getContext(), "other", Toast.LENGTH_SHORT).show();
        }
        if(v.getId()==R.id.cropsId){
            //Toast.makeText(getContext(), "other", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(getContext(), Crops_Activity.class));
        }
        if(v.getId()==R.id.fruitId){
            Toast.makeText(getContext(), "other", Toast.LENGTH_SHORT).show();
        }

    }
}