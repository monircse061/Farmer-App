package com.example.project.ui.slideshow;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class SlideshowViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public SlideshowViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("যেকোনো প্রকার জিজ্ঞাসা এবং সহযোগিতার জন্য http://www.farmerhelpbd.com ওয়েবসাইটে ভিজিট করুন অথবা আমাদের হেল্পলাইন ১৬৪৪৪ নাম্বারে যোগাযোগ করুন");
    }

    public LiveData<String> getText() {
        return mText;
    }
}