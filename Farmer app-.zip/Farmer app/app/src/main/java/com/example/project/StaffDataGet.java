package com.example.project;

public class StaffDataGet {
    private String Name;
    private String Phone;
    private String Address;
    private String Query;

    public StaffDataGet(String name, String phone, String address, String query) {
        Name = name;
        Phone = phone;
        Address = address;
        Query = query;
    }

    public StaffDataGet() {
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getQuery() {
        return Query;
    }

    public void setQuery(String query) {
        Query = query;
    }
}
